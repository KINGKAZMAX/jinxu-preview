# 锦序 JinXu｜1995.73 案例包（来源补全版）

设计与流程整理：蔡智鑫。来源补全日期：2026-11-21。

本包从旧案例包复制，仅补全出处及项目名称。原始嵌入图、裁切、铺排、数量、场景参数、色板和三个PNG保持一致。

## 馆藏记录

- 馆藏：The Cleveland Museum of Art，编号1995.73。
- 官方标题：Textile with Phoenixes and Dragons（凤龙纹织物）。
- 年代：1279–1368；文化字段：China, Yuan dynasty (1260–1368)。
- 材料及技法：Silk and gold thread; lampas。
- Credit line：Edward L. Whittemore Fund。
- 官方对象页：https://www.clevelandart.org/art/1995.73
- 开放获取说明：https://www.clevelandart.org/open-access
- 对象页允许复制、修改及分发；机构开放获取说明采用CC0。保留出处用于学术追溯，并不表示机构参与或认可本项目。

## 演示边界

本对象用于“图像—提色—裁切—铺排—交接”的数字流程演示。它不是已确认的南京云锦馆藏，也不作为妆花工艺复原证据。颜色为图像提色参考，不能作为原件测色结果。

项目及 review.json 继续保留 draft；来源、循环、空间检查均未勾选。不宣称样织已完成、工艺师已认可、第三方交接已通过，也不宣称本次仅补全元数据就完成了图像与原件的独立比对。

## 文件与打开方式

在锦序素材馆/创作台使用“导入项目包”选择本ZIP，恢复嵌入图和参数。project.json为可重开项目；references.json为来源与参考色板；review.json为未完成的审核状态。motif.png、tile.png、repeat.png分别保留原包输出。

## 本次更改

project.json：补全source.title/url/license/credit、改为有意义的项目名称。
references.json：补全同一imageSource，加入官方馆藏参考条目。
其余原文件不变。source-verification.json记录本次核读与原文件哈希。
